
import React from 'react';
import { MoodType } from './types';

export interface MoodItem {
  id: MoodType;
  label: string;
  emoji: string;
}

export const MOODS: MoodItem[] = [
  { id: 'Epic', label: 'Эпично', emoji: '💥' },
  { id: 'Romantic', label: 'Романтично', emoji: '❤️' },
  { id: 'Scared', label: 'Страшно', emoji: '😱' },
  { id: 'Funny', label: 'Весело', emoji: '😂' },
  { id: 'Mysterious', label: 'Загадочно', emoji: '🧐' },
  { id: 'Relaxed', label: 'Расслабленно', emoji: '🍿' },
];

export const MOCK_MOVIES = [
  {
    id: '1',
    title: 'Interstellar',
    year: 2014,
    duration: '169 min',
    rating: 8.7,
    genres: ['Sci-Fi', 'Adventure'],
    description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    posterUrl: 'https://picsum.photos/seed/interstellar/400/600',
    actors: [
      { name: 'Matthew McConaughey', imageUrl: 'https://picsum.photos/seed/actor1/100/100' },
      { name: 'Anne Hathaway', imageUrl: 'https://picsum.photos/seed/actor2/100/100' }
    ]
  },
  {
    id: '2',
    title: 'Dune: Part Two',
    year: 2024,
    duration: '166 min',
    rating: 8.9,
    genres: ['Sci-Fi', 'Action'],
    description: "Paul Atreides unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family.",
    posterUrl: 'https://picsum.photos/seed/dune/400/600',
    actors: [
      { name: 'Timothée Chalamet', imageUrl: 'https://picsum.photos/seed/actor3/100/100' },
      { name: 'Zendaya', imageUrl: 'https://picsum.photos/seed/actor4/100/100' }
    ]
  }
];
