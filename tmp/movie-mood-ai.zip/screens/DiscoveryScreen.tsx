
import React from 'react';
import { Movie, Screen } from '../types';

interface Props {
  movies: Movie[];
  currentIndex: number;
  onLike: (movie: Movie) => void;
  onPass: () => void;
  onDetails: (movie: Movie) => void;
  onNavigate: (screen: Screen) => void;
}

export const DiscoveryScreen: React.FC<Props> = ({ movies, currentIndex, onLike, onPass, onDetails, onNavigate }) => {
  const currentMovie = movies[currentIndex];

  if (!currentMovie) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center p-8 text-center bg-background">
        <span className="material-symbols-outlined text-primary text-6xl mb-4">sentiment_very_satisfied</span>
        <h2 className="text-2xl font-bold mb-2">You've seen everything!</h2>
        <p className="text-white/50 mb-8">Try a different mood to find more cinematic treasures.</p>
        <button 
          onClick={() => onNavigate('MOOD_GRID')}
          className="bg-primary px-8 py-3 rounded-xl font-bold text-white shadow-lg shadow-primary/20"
        >
          Select Another Mood
        </button>
      </div>
    );
  }

  return (
    <div className="h-screen w-full flex flex-col bg-background overflow-hidden">
      <header className="flex items-center justify-between px-6 py-4">
        <button onClick={() => onNavigate('PROFILE')} className="size-10 rounded-full glass flex items-center justify-center">
          <span className="material-symbols-outlined text-white/70">person</span>
        </button>
        <div className="text-center">
          <h1 className="text-lg font-bold">Movie Mood</h1>
          <div className="flex items-center justify-center gap-1">
            <span className="size-1.5 rounded-full bg-primary animate-pulse"></span>
            <span className="text-[10px] uppercase tracking-widest text-white/50 font-medium">Discovering</span>
          </div>
        </div>
        <button className="size-10 rounded-full glass flex items-center justify-center">
          <span className="material-symbols-outlined text-white/70">tune</span>
        </button>
      </header>

      <main className="flex-1 relative px-4 py-2 flex items-center justify-center">
        <div className="relative w-full max-w-[400px] aspect-[2/3] group swipe-card">
          <div className="absolute inset-0 rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-surface">
            <img src={currentMovie.posterUrl} className="w-full h-full object-cover" alt={currentMovie.title} />
            
            <div className="absolute top-4 left-4 z-20">
              <div className="bg-primary px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-lg shadow-primary/30">
                <span className="material-symbols-outlined text-[16px] fill-1 text-white">auto_awesome</span>
                <span className="text-[10px] font-bold uppercase tracking-wider text-white">AI Choice</span>
              </div>
            </div>

            <div className="absolute bottom-0 inset-x-0 p-6 pt-20 bg-gradient-to-t from-background via-background/90 to-transparent">
              <div className="glass p-4 rounded-xl border border-white/5">
                <div className="flex justify-between items-start mb-2">
                  <h2 className="text-2xl font-bold leading-tight">{currentMovie.title}</h2>
                  <div className="flex items-center bg-white/10 px-2 py-0.5 rounded-lg gap-1 border border-white/5">
                    <span className="material-symbols-outlined text-yellow-400 text-sm fill-1">star</span>
                    <span className="text-xs font-bold">{currentMovie.rating}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mb-3">
                  {currentMovie.genres.map(g => (
                    <span key={g} className="text-[10px] font-bold text-white/60 bg-white/5 px-2 py-1 rounded-md border border-white/5 uppercase tracking-wider">{g}</span>
                  ))}
                  <span className="text-[10px] font-bold text-white/60 bg-white/5 px-2 py-1 rounded-md border border-white/5 uppercase tracking-wider">{currentMovie.duration}</span>
                </div>
                <p className="text-sm text-white/50 line-clamp-2 leading-relaxed">
                  {currentMovie.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <div className="px-6 py-8 flex items-center justify-center gap-10">
        <button 
          onClick={onPass}
          className="group flex flex-col items-center gap-2 active:scale-90 transition-transform"
        >
          <div className="size-16 rounded-full bg-red-500/10 border-2 border-red-500/20 text-red-500 flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">
            <span className="material-symbols-outlined text-3xl">close</span>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-red-500/50">Pass</span>
        </button>

        <button 
          onClick={() => onDetails(currentMovie)}
          className="group flex flex-col items-center gap-2 active:scale-90 transition-transform"
        >
          <div className="size-12 rounded-full glass border border-white/10 text-white/40 flex items-center justify-center hover:text-white transition-all">
            <span className="material-symbols-outlined text-2xl">info</span>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-white/20">Details</span>
        </button>

        <button 
          onClick={() => onLike(currentMovie)}
          className="group flex flex-col items-center gap-2 active:scale-90 transition-transform"
        >
          <div className="size-16 rounded-full bg-emerald-500/10 border-2 border-emerald-500/20 text-emerald-500 flex items-center justify-center hover:bg-emerald-500 hover:text-white transition-all">
            <span className="material-symbols-outlined text-3xl fill-1">favorite</span>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-500/50">Keep</span>
        </button>
      </div>

      <nav className="glass-nav border-t border-white/5 pb-10 pt-4 px-8 flex justify-between items-center bg-surface/80">
        <button onClick={() => onNavigate('DISCOVERY')} className="flex flex-col items-center gap-1 text-primary">
          <span className="material-symbols-outlined text-2xl fill-1">explore</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Discover</span>
        </button>
        <button onClick={() => onNavigate('WATCHLIST')} className="flex flex-col items-center gap-1 text-white/40">
          <span className="material-symbols-outlined text-2xl">bookmarks</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Watchlist</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-white/40">
          <span className="material-symbols-outlined text-2xl">leaderboard</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Top 10</span>
        </button>
        <button onClick={() => onNavigate('PROFILE')} className="flex flex-col items-center gap-1 text-white/40">
          <span className="material-symbols-outlined text-2xl">settings</span>
          <span className="text-[10px] font-bold uppercase tracking-widest">Settings</span>
        </button>
      </nav>
    </div>
  );
};
