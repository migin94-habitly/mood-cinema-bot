
import React from 'react';

interface Props {
  onStart: () => void;
}

export const WelcomeScreen: React.FC<Props> = ({ onStart }) => {
  return (
    <div className="relative h-screen w-full flex flex-col justify-between p-6 pb-12 text-center bg-background">
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full bg-center bg-cover bg-no-repeat opacity-40 blur-sm"
          style={{ backgroundImage: `url('https://picsum.photos/seed/cinema/800/1200')` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
      </div>

      <div className="relative z-10 pt-20 flex flex-col items-center">
        <div className="w-16 h-16 bg-primary/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-primary/30 mb-4 shadow-lg shadow-primary/20">
          <span className="material-symbols-outlined text-primary text-4xl" style={{ fontVariationSettings: "'FILL' 1" }}>movie_filter</span>
        </div>
        <h1 className="text-sm font-bold tracking-[0.2em] uppercase text-primary/80 mb-8">Movie Mood</h1>
        <h2 className="text-4xl font-bold leading-tight mb-4">
          Find Your <span className="text-primary">Perfect</span> Movie Tonight
        </h2>
        <p className="text-white/60 text-lg max-w-[280px]">
          AI-powered suggestions based on your mood and swipes.
        </p>
      </div>

      <div className="relative z-10 w-full max-w-md mx-auto space-y-6">
        <div className="flex justify-center gap-8 opacity-60">
          <div className="flex flex-col items-center gap-1">
            <span className="material-symbols-outlined">mood</span>
            <span className="text-[10px] uppercase tracking-widest">Mood</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <span className="material-symbols-outlined">swipe</span>
            <span className="text-[10px] uppercase tracking-widest">Swipe</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <span className="material-symbols-outlined">psychology</span>
            <span className="text-[10px] uppercase tracking-widest">AI Match</span>
          </div>
        </div>
        <button 
          onClick={onStart}
          className="w-full flex items-center justify-center gap-3 bg-primary hover:bg-primary/90 text-white font-bold text-lg h-14 rounded-xl transition-all shadow-xl shadow-primary/20 active:scale-[0.98]"
        >
          <span>Get Started</span>
          <span className="material-symbols-outlined">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};
