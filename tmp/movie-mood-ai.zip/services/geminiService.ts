
import { GoogleGenAI, Type } from "@google/genai";
import { Movie, MoodType } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const movieSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      year: { type: Type.NUMBER },
      duration: { type: Type.STRING },
      rating: { type: Type.NUMBER },
      genres: { type: Type.ARRAY, items: { type: Type.STRING } },
      description: { type: Type.STRING },
      posterUrl: { type: Type.STRING, description: 'Return a descriptive URL or use a placeholder if unknown' },
      actors: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            imageUrl: { type: Type.STRING }
          },
          required: ['name', 'imageUrl']
        }
      }
    },
    required: ['id', 'title', 'year', 'duration', 'rating', 'genres', 'description', 'posterUrl', 'actors'],
  },
};

export async function getMovieRecommendations(mood: MoodType): Promise<Movie[]> {
  const prompt = `Act as a movie recommendation expert. Suggest 5 movies that perfectly fit a '${mood}' mood. 
  For each movie, provide realistic details including title, release year, duration, IMDb-like rating, genres, 
  a short engaging description, and a few main cast members. 
  For images, please use 'https://picsum.photos/seed/{movie_title_no_spaces}/400/600' for posterUrl 
  and 'https://picsum.photos/seed/{actor_name_no_spaces}/100/100' for actor image URLs.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: movieSchema,
        thinkingConfig: { thinkingBudget: 2000 }
      },
    });

    if (!response.text) return [];
    const movies: Movie[] = JSON.parse(response.text);
    return movies;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [];
  }
}
